'use strict';
const piece=document.querySelector('iframe'),nav=document.querySelector('nav');
const sections=[['intro','Intro','pieces/intro/'],['flower','Flowers','pieces/flower/'],['cake','Cake','pieces/cake/'],['heart','Heart','pieces/heart/'],['outro','Letter','pieces/outro/']];
let seen=new Set(),current='intro';
try{const saved=JSON.parse(sessionStorage.getItem('ngl-seen')||'[]');if(Array.isArray(saved))seen=new Set(saved.filter(id=>sections.some(s=>s[0]===id)))}catch{}
function visit(id){current=id;seen.add(id);try{sessionStorage.setItem('ngl-seen',JSON.stringify([...seen]))}catch{}render()}
function render(){nav.replaceChildren();for(const [id,label,url] of sections){if(!seen.has(id))continue;const link=document.createElement('a');link.textContent=label;link.href=url;link.target=piece.name;if(id===current)link.setAttribute('aria-current','page');link.addEventListener('click',event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();piece.src=url});nav.append(link)}}
piece.name='gift-piece';
piece.addEventListener('load',()=>{if(!piece.getAttribute('src'))return;const path=piece.contentWindow.location.pathname;const section=sections.find(([id])=>path.includes('/pieces/'+id+'/'));if(section)visit(section[0]);if(!matchMedia('(prefers-reduced-motion: reduce)').matches)piece.animate([{opacity:0},{opacity:1}],{duration:650,easing:'ease-out'})});
addEventListener('message',event=>{if(event.origin===location.origin&&event.source===piece.contentWindow&&event.data==='heart-section-started')visit('heart')});

