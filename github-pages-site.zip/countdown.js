'use strict';
// An explicit UTC offset keeps the reveal at Bangkok midnight on every device.
const birthdayAt=Date.parse('2026-11-07T00:00:00+07:00');
const countdown=document.querySelector('.countdown'),header=document.querySelector('header');
const clockParts=['hours','minutes','seconds'].map(id=>document.getElementById(id));
let birthdayStarted=false,countdownInterval;
function countdownParts(now){const total=Math.max(0,Math.ceil((birthdayAt-now)/1000));return[Math.floor(total/3600),Math.floor(total/60)%60,total%60]}
function updateCountdown(){
 if(birthdayStarted)return;
 const now=Date.now(),parts=countdownParts(now);
 parts.forEach((value,i)=>{clockParts[i].textContent=String(value).padStart(2,'0')});
 countdown.querySelector('[role="timer"]').setAttribute('aria-label',`${parts[0]} hours, ${parts[1]} minutes, ${parts[2]} seconds until your birthday`);
 if(now<birthdayAt)return;
 birthdayStarted=true;clearInterval(countdownInterval);
 // Load only at unlock: the intro starts from its very first frame.
 piece.addEventListener('load',()=>{
  document.body.classList.remove('waiting-for-midnight');document.body.classList.add('birthday-unlocked');
  header.inert=false;header.removeAttribute('aria-hidden');piece.inert=false;piece.removeAttribute('aria-hidden');countdown.setAttribute('aria-hidden','true');
  setTimeout(()=>{countdown.hidden=true;countdown.style.display='none'},matchMedia('(prefers-reduced-motion: reduce)').matches?0:1050);
 },{once:true});
 piece.src='pieces/intro/';
}
countdownInterval=setInterval(updateCountdown,250);
addEventListener('pageshow',updateCountdown);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)updateCountdown()});
updateCountdown();
