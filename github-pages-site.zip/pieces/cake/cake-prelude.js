'use strict';
(()=>{
 const overlay=document.querySelector('.cake-prelude'),lines=[...overlay.querySelectorAll('.prelude-line')],content=document.querySelector('main');
 const sequence=[{start:200,end:3600},{start:4100,end:7400},{start:7900,end:9700},{start:10200,end:13200}];
 document.addEventListener('visibilitychange',()=>{previous=0});
 let elapsed=0,previous=0,revealed=false,lit=false,interactive=false;
 lines.forEach(line=>line.setAttribute('aria-hidden','true'));
 function frame(now){const dt=previous?Math.max(0,now-previous):0;previous=now;if(!document.hidden)elapsed+=dt;
 lines.forEach((line,i)=>{const showing=elapsed>=sequence[i].start&&elapsed<sequence[i].end;line.classList.toggle('visible',showing);line.setAttribute('aria-hidden',String(!showing))});
 if(elapsed>=13200&&!revealed){revealed=true;overlay.classList.add('finished');document.body.classList.add('lights-out');document.body.classList.remove('before-cake')}
 if(elapsed>=14200&&!lit){lit=true;document.body.classList.add('candlelit')}
 if(elapsed>=16400&&!interactive){interactive=true;content.removeAttribute('inert');content.removeAttribute('aria-hidden')}
 if(elapsed>=16600){overlay.hidden=true;return}requestAnimationFrame(frame)
 }
 Promise.race([document.fonts.ready,new Promise(resolve=>setTimeout(resolve,1500))]).then(()=>requestAnimationFrame(frame));
 console.assert(lines.length===4&&sequence.every((x,i)=>x.start<x.end&&(!i||x.start>sequence[i-1].end)),'Birthday prelude sequence invalid');
})();
