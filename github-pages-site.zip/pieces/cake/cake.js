'use strict';
const stage=document.querySelector('#cake'),container=document.querySelector('#candles'),wish=document.querySelector('#wish'),relight=document.querySelector('#relight');
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const candles=[];let blowing=false,timers=[];
// Three staggered rows give all nineteen candles their own space.
const rows=[{count:6,left:28,right:72,y:35.5,height:8.3},{count:7,left:25,right:75,y:39,height:7.5},{count:6,left:29,right:71,y:43,height:6.7}];
rows.forEach((row,r)=>{for(let i=0;i<row.count;i++){const u=i/(row.count-1),c=document.createElement('span');c.className='candle';c.style.left=(row.left+u*(row.right-row.left))+'%';c.style.top=(row.y+Math.sin(u*Math.PI)*(r===0?-1:0.6))+'%';c.style.zIndex=String(r+2);c.style.height=(row.height+(i%3-1)*.35)+'%';c.style.setProperty('--speed',(1.05+(i%4)*.16)+'s');c.style.setProperty('--lean',[-1.5,1,-.5,1.5][i%4]+'deg');c.innerHTML='<span class="wax"></span><span class="wick"></span><span class="flame"></span><span class="smoke"></span>';container.append(c);candles.push(c)}});

function celebrate(){if(blowing)return;blowing=true;wish.disabled=true;stage.disabled=true;stage.setAttribute('aria-label','Nineteen candles blown out. Happy birthday, my love.');for(let i=0;i<candles.length;i++)timers.push(setTimeout(()=>candles[i].classList.add('out'),reduced.matches?0:i*65));timers.push(setTimeout(()=>stage.classList.add('blown'),reduced.matches?0:650));timers.push(setTimeout(()=>{document.body.classList.add('celebrated');relight.hidden=false;document.querySelector('#next-piece').hidden=false},reduced.matches?0:1900))}
function reset(){timers.forEach(clearTimeout);timers=[];blowing=false;stage.disabled=false;wish.disabled=false;stage.classList.remove('blown');document.body.classList.remove('celebrated');relight.hidden=true;for(const c of candles)c.classList.remove('out');stage.setAttribute('aria-label','Blow out all nineteen birthday candles');wish.focus()}
stage.onclick=celebrate;wish.onclick=celebrate;relight.onclick=reset;
console.assert(candles.length===19,'Birthday cake must have exactly nineteen candles');

const nextPiece=document.querySelector('#next-piece');
nextPiece.addEventListener('click',event=>{event.preventDefault();nextPiece.style.pointerEvents='none';const fade=document.querySelector('main').animate([{opacity:1},{opacity:0}],{duration:reduced.matches?0:650,fill:'forwards'});fade.finished.then(()=>location.href=nextPiece.href)});
