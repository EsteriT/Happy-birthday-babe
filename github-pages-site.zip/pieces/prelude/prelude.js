'use strict';
const section=document.querySelector('.prelude'),lines=[...section.querySelectorAll('p')],heartStage=document.querySelector('.heart-stage');
let elapsed=0,previous=0,heartStarted=false,backgroundShown=false;
const timing={starts:[100,3700,7400],ends:[3300,7000,11900],background:9800,fade:11900,complete:13400};
function startHeart(){heartStage.contentWindow.postMessage('start-heart',location.origin);if(parent!==window)parent.postMessage('heart-section-started',location.origin)}
function showBackground(){if(backgroundShown)return;backgroundShown=true;heartStage.classList.add('visible');heartStage.contentWindow.postMessage('show-heart-background',location.origin)}
heartStage.addEventListener('load',()=>{if(backgroundShown)heartStage.contentWindow.postMessage('show-heart-background',location.origin);if(heartStarted)startHeart()});
document.addEventListener('visibilitychange',()=>{previous=0});
function frame(now){const dt=previous?Math.max(0,now-previous):0;previous=now;if(!document.hidden)elapsed+=dt;
 lines.forEach((line,i)=>line.classList.toggle('visible',elapsed>=timing.starts[i]&&elapsed<timing.ends[i]));
 if(elapsed>=timing.background)showBackground();
 if(elapsed>=timing.fade&&!heartStarted){heartStarted=true;section.classList.add('departing');heartStage.removeAttribute('aria-hidden');heartStage.removeAttribute('inert');startHeart();document.title='A heart for Ngl'}
 if(elapsed>=timing.complete){document.body.classList.add('heart-active');section.setAttribute('aria-hidden','true');return}requestAnimationFrame(frame);
}
Promise.race([document.fonts.ready,new Promise(resolve=>setTimeout(resolve,1500))]).then(()=>requestAnimationFrame(frame));
console.assert(lines.length===3&&timing.ends[2]===timing.fade,'Birthday prelude must finish before the heart begins');
