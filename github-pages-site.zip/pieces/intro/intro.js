'use strict';
const names=['one and only','love','girlfriend','little girl','favorite person','forever','Ngl'];
const hold=2800;
const windowElement=document.querySelector('.name-window'),heartPath=document.querySelector('.heart-line path'),invitation=document.querySelector('.invitation');
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
let index=0,busy=false,current=windowElement.querySelector('.name'),timer,animations=[],started=false,heartAnimation,deadline=0,remaining=null;
function fit(node){node.style.fontSize='';const available=windowElement.clientWidth-24;const probe=document.createElement('canvas').getContext('2d');const style=getComputedStyle(node);probe.font=`${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;const measured=probe.measureText(node.textContent).width;if(measured>available)node.style.fontSize=`${+style.fontSize.replace('px','')*available/measured}px`}
function revealInvitation(){invitation.classList.add('visible');invitation.removeAttribute('inert');invitation.removeAttribute('aria-hidden')}
function schedule(){clearTimeout(timer);if(document.hidden||!started)return;const delay=remaining??hold;remaining=null;deadline=performance.now()+delay;timer=setTimeout(()=>{if(index===names.length-1)revealInvitation();else change()},delay)}
function finishQuietly(){clearTimeout(timer);heartAnimation?.cancel();for(const a of animations)a.finish();current.textContent='Ngl';current.classList.add('important');index=names.length-1;fit(current);heartPath.style.strokeDashoffset='0';document.title='For my Ngl';revealInvitation()}
async function change(){if(busy||index>=names.length-1)return;busy=true;index++;const incoming=document.createElement('span');incoming.className='name';incoming.textContent=names[index];incoming.classList.toggle('important',['love','little girl','Ngl'].includes(names[index]));windowElement.append(incoming);fit(incoming);
 if(!reduce.matches){const options={duration:1100,easing:'cubic-bezier(.2,.8,.2,1)',fill:'both'};animations=[current.animate([{transform:'translateY(0)',opacity:1},{transform:'translateY(-110%)',opacity:0}],options),incoming.animate([{transform:'translateY(110%)',opacity:0},{transform:'translateY(0)',opacity:1}],options)];await Promise.all(animations.map(a=>a.finished.catch(()=>{})))}
 current.remove();for(const a of animations)a.cancel();animations=[];current=incoming;current.classList.add('current');busy=false;document.title=`For my ${names[index]}`;
 if(reduce.matches)finishQuietly();else schedule();
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){remaining=Math.max(0,deadline-performance.now());clearTimeout(timer);heartAnimation?.pause()}else{if(heartAnimation?.playState==='paused')heartAnimation.play();schedule()}});
reduce.addEventListener('change',()=>{if(reduce.matches)finishQuietly()});
addEventListener('resize',()=>fit(current));
invitation.addEventListener('click',async e=>{if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||reduce.matches)return;e.preventDefault();if(invitation.dataset.leaving)return;invitation.dataset.leaving='true';const fade=document.querySelector('main').animate([{opacity:1},{opacity:0}],{duration:650,easing:'ease-in',fill:'forwards'});await fade.finished;location.href=invitation.href});
Promise.race([Promise.all([document.fonts.load('700 120px Lora'),document.fonts.load('500 100px Lora')]),new Promise(resolve=>setTimeout(resolve,2500))]).then(()=>{started=true;fit(current);if(reduce.matches)finishQuietly();else{const duration=(names.length-1)*(hold+1100);heartAnimation=heartPath.animate([{strokeDashoffset:'1'},{strokeDashoffset:'0'}],{duration,easing:'linear',fill:'forwards'});if(document.hidden)heartAnimation.pause();schedule()}});
console.assert(names.at(-1)==='Ngl'&&new Set(names).size===names.length,'Intro sequence invalid');
