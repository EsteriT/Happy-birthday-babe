'use strict';
const scene=document.querySelector('.envelope-scene'),envelope=document.querySelector('.envelope'),main=document.querySelector('main');
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
setTimeout(()=>{document.body.classList.add('ready');scene.inert=false;scene.removeAttribute('aria-hidden');document.querySelector('.outro-prelude').setAttribute('aria-hidden','true')},2400);
envelope.addEventListener('click',()=>{
 if(envelope.disabled)return;
 envelope.disabled=true;envelope.setAttribute('aria-expanded','true');document.body.classList.add('opening');
 setTimeout(()=>{document.body.classList.remove('sealed');document.body.classList.add('letter-open');scene.inert=true;scene.setAttribute('aria-hidden','true');main.inert=false;main.removeAttribute('aria-hidden');document.querySelector('#letter').focus({preventScroll:true})},reduced.matches?200:1600);
});
