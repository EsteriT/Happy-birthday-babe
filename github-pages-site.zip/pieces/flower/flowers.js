'use strict';
const canvas=document.querySelector('#flowers'),ctx=canvas.getContext('2d',{alpha:false});
const source=document.createElement('canvas');source.width=600;source.height=780;
const ink=source.getContext('2d');
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
let width=0,height=0,dpr=1,elapsed=reduce.matches?9:0,previous=0,paused=false,flowersStarted=false;
const clamp=x=>Math.max(0,Math.min(1,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
let seed=73;function random(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}
const palette={red:[220,39,57],pink:[223,90,155],cream:[240,222,185],yellow:[230,190,52],rose:[235,61,137],coral:[255,101,85],peach:[255,178,123],lavender:[187,146,255],violet:[145,77,230],apricot:[255,153,65]};
// Back-to-front order gives the bouquet its overlapping, gathered silhouette.
const flowers=[
 [278,156,31,-.12,'cream',.2],[354,178,30,.30,'lavender',.45],[208,204,34,-.38,'peach',.6],
 [409,238,33,.50,'yellow',.25],[166,283,35,-.50,'yellow',.7],[318,252,49,.10,'red',.1],
 [445,335,42,.48,'violet',.65],[223,348,47,-.30,'pink',.35],[359,369,43,.32,'apricot',.7],
 [151,405,37,-.50,'yellow',.45],[282,435,51,-.16,'pink',.55],[413,455,42,.50,'coral',.85],
 [198,502,43,-.35,'lavender',.9],[333,515,51,.23,'cream',.4],[274,582,37,-.20,'cream',1.1],
 [247,235,30,-.20,'coral',.55],[384,307,31,.28,'lavender',.75],
 [175,350,31,-.38,'peach',.85],[378,535,35,.30,'rose',1.0]
].sort((a,b)=>a[1]-b[1]).map((f,i)=>({x:f[0],y:f[1],size:f[2]*1.43,angle:f[3],color:palette[f[4]],delay:f[5],phase:random()*6.28,root:275+random()*48,index:i}));
const reasons=[
 'I love your hair','I love your eyes','I love your nose','I love your forehead. hehe',
 'I love your face','I love your little cheeks','I love your beautiful smile','I love your laugh',
 'I love making you laugh','I love watching you smile','I love your arms','I love holding your hand',
 'I love hugging you','I love your legs','I love your little belly','I love your booty',
 'I love everything that you do','I love you because you are you','I love you'
];
let selected=-1,targetsReady=false;const opened=flowers.map(()=>0),visited=new Set();
const targetLayer=document.querySelector('#flower-targets'),note=document.querySelector('#love-note'),noteText=document.querySelector('#reason'),noteCount=document.querySelector('#reason-count'),noteClose=document.querySelector('#close-note');
const targets=flowers.map((f,i)=>{const button=document.createElement('button');button.type='button';button.className='flower-target';button.setAttribute('aria-label',`Tulip ${i+1}: open a reason I love you`);button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls','love-note');button.disabled=true;button.onclick=()=>selectFlower(i);targetLayer.append(button);return button});
function placeTargets(){const scale=Math.min(width/600,(height-70)/780),ox=(width-600*scale)/2,oy=(height-780*scale)/2;flowers.forEach((f,i)=>{const centerX=f.x+Math.sin(f.angle)*f.size*.6,centerY=f.y-20-Math.cos(f.angle)*f.size*.6;targets[i].style.left=(ox+centerX*scale)+'px';targets[i].style.top=(oy+centerY*scale)+'px';const size=Math.max(28,Math.min(54,f.size*.9*scale));targets[i].style.width=targets[i].style.height=size+'px'})}
function selectFlower(i){selected=i;visited.add(i);noteText.textContent=reasons[i];noteCount.textContent=String(i+1).padStart(2,'0')+' / 19';note.hidden=false;targets.forEach((b,j)=>{b.classList.toggle('selected',j===i);b.classList.toggle('visited',visited.has(j));b.setAttribute('aria-expanded',String(j===i))});document.querySelector('.tap-hint').hidden=true;noteClose.focus({preventScroll:true})}
function closeNote(){const old=selected;selected=-1;note.hidden=true;targets.forEach(b=>{b.classList.remove('selected');b.setAttribute('aria-expanded','false')});if(old>=0)targets[old].focus({preventScroll:true})}
noteClose.onclick=closeNote;document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!note.hidden)closeNote()});
document.addEventListener('pointerdown',e=>{if(!note.hidden&&!note.contains(e.target)&&!targetLayer.contains(e.target))closeNote()});
const pencil=document.createElement('canvas');pencil.width=pencil.height=180;
const grain=pencil.getContext('2d');
for(let i=0;i<2200;i++){const x=random()*180,y=random()*180;grain.strokeStyle=i%4?'rgba(83,48,60,.16)':'rgba(255,245,225,.45)';grain.lineWidth=.35+random()*.45;grain.beginPath();grain.moveTo(x,y);grain.lineTo(x+3+random()*10,y-2-random()*5);grain.stroke()}
const pencilFill=ink.createPattern(pencil,'repeat');
function roughPetal(w,h,s){const path=new Path2D();
 const segments=[[[0,s*.4],[-w*1.13,s*.18],[-w*1.20,-h*.40],[-w*.77,-h*.86]],[[-w*.77,-h*.86],[-w*.45,-h*1.09],[w*.21,-h*1.11],[w*.66,-h*.91]],[[w*.66,-h*.91],[w*1.10,-h*.50],[w*1.12,s*.16],[0,s*.4]]];
 path.moveTo(0,s*.4);let n=0;for(const [a,b,c,d] of segments)for(let i=1;i<=20;i++){const t=i/20,u=1-t;const x=u*u*u*a[0]+3*u*u*t*b[0]+3*u*t*t*c[0]+t*t*t*d[0],y=u*u*u*a[1]+3*u*u*t*b[1]+3*u*t*t*c[1]+t*t*t*d[1];n++;path.lineTo(x+Math.sin(n*2.7)*.48,y+Math.sin(n*1.8)*.4)}path.closePath();return path;
}
function resize(){width=innerWidth;height=innerHeight;dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);placeTargets()}
addEventListener('resize',resize);resize();
function leaf(x,y,dx,dy,growth){if(growth<=0)return;ink.save();ink.translate(x,y);ink.scale(growth,growth);ink.beginPath();ink.moveTo(0,0);ink.bezierCurveTo(dx*.1,dy*.75,dx*.8,dy*.6,dx,dy);ink.bezierCurveTo(dx*.7,dy*.1,dx*.25,dy*.08,0,0);ink.fillStyle='#a6b785';ink.fill();ink.strokeStyle='#443c35';ink.lineWidth=1.2;ink.stroke();ink.save();ink.clip();ink.fillStyle=pencilFill;ink.fillRect(Math.min(0,dx),dy,Math.abs(dx),-dy);ink.restore();ink.strokeStyle='#607445';ink.lineWidth=.8;ink.beginPath();ink.moveTo(0,0);ink.quadraticCurveTo(dx*.45,dy*.45,dx,dy);ink.stroke();ink.restore()}
// Pencil work is painted once; frames only transform cached petal images.
const petalArt=new Map();
function makePetalArt(color,back){const tile=document.createElement('canvas');tile.width=160;tile.height=230;const pen=tile.getContext('2d');pen.translate(80,180);
 const w=50,h=160,s=100,path=roughPetal(w,h,s),tint=color.map((v,i)=>Math.round(v*(back?.69:.72)+[255,240,218][i]*(back?.23:.28)));
 pen.fillStyle=`rgb(${tint})`;pen.fill(path);pen.save();pen.clip(path);pen.fillStyle=pen.createPattern(pencil,'repeat');pen.fillRect(-w*1.4,-h*1.2,w*2.8,h*1.8);
 pen.strokeStyle='#6b42504d';pen.lineWidth=.55;for(let i=0;i<9;i++){const x=-w+i*w*.24,y=-h*.35+(i%3)*h*.12;pen.beginPath();pen.moveTo(x,y);pen.lineTo(x+w*.42,y-h*.15);pen.stroke()}
 pen.strokeStyle='#72465540';for(let j=-1;j<=1;j++){pen.beginPath();pen.moveTo(j*2,s*.3);pen.quadraticCurveTo(j*w*.4,-h*.45,j*w*.4,-h*.9);pen.stroke()}pen.restore();pen.strokeStyle='#49353c';pen.lineWidth=back?1:1.3;pen.stroke(path);pen.translate(.9,-.55);pen.globalAlpha=.30;pen.lineWidth=.55;pen.stroke(path);return tile;
}
for(const color of Object.values(palette))for(const back of [false,true])petalArt.set(color.join(',')+back,makePetalArt(color,back));
function petal(size,side,open,color,back=false){const s=size,w=s*(.22+open*.29),h=s*(1.65-open*.12),art=petalArt.get(color.join(',')+back);
 ink.save();ink.translate(side*s*(.05+open*.39),-Math.abs(side)*s*open*.12);ink.rotate(side*(.03+open*.27));ink.drawImage(art,-80*w/50,-180*h/160,160*w/50,230*h/160);ink.restore();
}
function drawFlower(f,t,stems=false){const grow=ease((t-f.delay)/2.6),open=ease((t-2.05-f.delay)/4.5)*(0.72+0.28*Math.sin(f.phase)**2)+opened[f.index]*.35;if(grow===0)return;
 const sway=reduce.matches?0:Math.sin(t*.65+f.phase)*2.2*grow;
 const x=f.root+(f.x-f.root)*grow+sway,y=749+(f.y-20-749)*grow;
 if(stems){ink.lineCap='round';ink.beginPath();ink.moveTo(f.root,755);ink.bezierCurveTo(f.root-8,657,x+12,y+110,x,y);ink.strokeStyle='#493b35';ink.lineWidth=6;ink.stroke();ink.strokeStyle='#a8b885';ink.lineWidth=3.8;ink.stroke();ink.strokeStyle='#657c4f';ink.lineWidth=.55;ink.stroke();
 const lg=ease((t-.7-f.delay)/2);const midx=f.root+(x-f.root)*.45;leaf(midx,701+(f.index%3)*10,(f.index%2?1:-1)*65,-65-f.index%4*10,lg);return;}
 if(t>1.15+f.delay){const bud=ease((t-1.15-f.delay)/1.1);ink.save();ink.translate(x,y);ink.rotate(f.angle+sway*.005);ink.scale(bud,bud);petal(f.size*.84,0,open,f.color,true);petal(f.size,-.62,open,f.color,true);petal(f.size,.62,open,f.color,true);petal(f.size*.83,-.65,open,f.color);petal(f.size*.87,.65,open,f.color);petal(f.size*.76,0,open,f.color);ink.restore()}
}
function render(t){ink.clearRect(0,0,600,780);
 // Paint all greenery first so no later stem can cross a foreground bloom.
 for(const f of flowers)drawFlower(f,t,true);
 for(let i=0;i<5;i++)leaf(285+i*5,754,(i-2)*28,-20-Math.abs(i-2)*10,ease((t-1.1)/2.8));
 for(const f of flowers)if(f.index!==selected)drawFlower(f,t);
 if(selected>=0)drawFlower(flowers[selected],t);
 const scale=Math.min(width/600,(height-70)/780),ox=(width-600*scale)/2,oy=(height-780*scale)/2;
 const bg=ctx.createRadialGradient(width/2,height*.45,0,width/2,height*.45,Math.max(width,height)*.7);bg.addColorStop(0,'#54303a');bg.addColorStop(1,'#30131d');ctx.fillStyle=bg;ctx.fillRect(0,0,width,height);ctx.save();ctx.translate(ox,oy);ctx.scale(scale,scale);ctx.drawImage(source,0,0);ctx.restore();}

function frame(now){const dt=previous?Math.max(0,(now-previous)/1000):0;previous=now;if(!document.hidden){if(flowersStarted&&!paused&&!reduce.matches)elapsed+=dt;for(let i=0;i<opened.length;i++)opened[i]+=(Number(i===selected)-opened[i])*(reduce.matches?1:1-Math.exp(-dt*6));if(flowersStarted&&!targetsReady&&elapsed>=7.8){targetsReady=true;targets.forEach(b=>b.disabled=false);targetLayer.classList.add('ready');document.querySelector('.tap-hint').hidden=false;document.querySelector('#next-piece').hidden=false}render(elapsed)}requestAnimationFrame(frame)}
document.querySelector('#replay').onclick=()=>{closeNote();targetsReady=false;targetLayer.classList.remove('ready');targets.forEach(b=>b.disabled=true);document.querySelector('.tap-hint').hidden=true;document.querySelector('#next-piece').hidden=true;elapsed=0;paused=false;document.querySelector('#pause').textContent='Pause';if(reduce.matches){elapsed=9}};
document.querySelector('#pause').onclick=e=>{paused=!paused;e.target.textContent=paused?'Resume':'Pause';e.target.setAttribute('aria-label',paused?'Resume animation':'Pause animation')};
reduce.addEventListener('change',()=>{if(reduce.matches)elapsed=9});
console.assert(reasons.length===19&&new Set(reasons).size===19,'Each tulip needs one unique reason');
console.assert(flowers.length===19&&flowers.every(f=>Number.isFinite(f.x)&&f.color.length===3),'Bouquet data invalid');
addEventListener('start-flowers',()=>{flowersStarted=true;elapsed=reduce.matches?9:0;previous=0});
requestAnimationFrame(frame);



const onward=document.querySelector('#next-piece');
onward.addEventListener('click',async event=>{if(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||reduce.matches)return;event.preventDefault();if(onward.dataset.leaving)return;onward.dataset.leaving='true';const fade=document.querySelector('main').animate([{opacity:1},{opacity:0}],{duration:650,easing:'ease-in',fill:'forwards'});await fade.finished;location.href=onward.href});

document.addEventListener('visibilitychange',()=>{previous=0});
