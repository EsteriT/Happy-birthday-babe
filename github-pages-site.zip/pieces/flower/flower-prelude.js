'use strict';
(()=>{
 const overlay=document.querySelector('.flower-prelude'),lines=[...overlay.querySelectorAll('.prelude-line')],content=document.querySelector('main');
 const sequence=[{start:200,end:3200},{start:3600,end:7000},{start:7400,end:11300}];
 document.addEventListener('visibilitychange',()=>{previous=0});
 let elapsed=0,previous=0,started=false;
 lines.forEach(line=>line.setAttribute('aria-hidden','true'));
 function frame(now){const dt=previous?Math.max(0,now-previous):0;previous=now;if(!document.hidden)elapsed+=dt;
 lines.forEach((line,i)=>{const active=elapsed>=sequence[i].start&&elapsed<sequence[i].end;line.classList.toggle('visible',active);line.setAttribute('aria-hidden',String(!active))});
 if(elapsed>=11300&&!started){started=true;overlay.classList.add('finished');document.body.classList.remove('before-flowers');content.removeAttribute('inert');content.removeAttribute('aria-hidden');dispatchEvent(new Event('start-flowers'))}
 if(elapsed>=12600){overlay.hidden=true;return}requestAnimationFrame(frame)
 }
 Promise.race([document.fonts.ready,new Promise(resolve=>setTimeout(resolve,1500))]).then(()=>requestAnimationFrame(frame));
 console.assert(lines.length===3&&sequence.every((x,i)=>x.start<x.end&&(!i||x.start>sequence[i-1].end)),'Flower prelude sequence invalid');
})();
