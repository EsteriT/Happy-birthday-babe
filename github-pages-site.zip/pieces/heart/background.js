'use strict';
(()=>{
 const layer=document.querySelector('.memory-background'),videos=[...layer.querySelectorAll('video')],reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let active=0,blending=false,blendElapsed=0,last=0,started=false,paused=false,assetReady=false;
 const deferred=new URLSearchParams(location.search).get('prelude')==='1';
 function play(video){if(!paused&&!reduced.matches)video.play().catch(()=>{})}
 function reveal(){if(started)return;started=true;document.body.classList.add('memory-visible');if(assetReady)play(videos[active])}
 addEventListener('message',e=>{if(e.origin===location.origin&&e.source===parent&&(e.data==='show-heart-background'||e.data==='start-heart'))reveal()});
 addEventListener('heart-pause',e=>{paused=e.detail;for(const v of videos)v.pause();if(!paused&&started&&assetReady){play(videos[active]);if(blending)play(videos[1-active])}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)videos.forEach(v=>v.pause());else if(started&&assetReady&&!paused){play(videos[active]);if(blending)play(videos[1-active])}});
 reduced.addEventListener('change',()=>{if(reduced.matches)videos.forEach(v=>v.pause());else if(started)play(videos[active])});
 fetch('photostrip.mp4').then(r=>{if(!r.ok)throw Error('Video unavailable');return r.blob()}).then(blob=>{const url=URL.createObjectURL(blob);for(const v of videos){v.src=url;v.load()}assetReady=true;if(started)play(videos[active]);addEventListener('pagehide',()=>URL.revokeObjectURL(url),{once:true})}).catch(()=>{layer.hidden=true});
 function loop(now){const dt=last?Math.min(now-last,100):0;last=now;const v=videos[active],next=videos[1-active];if(started&&assetReady&&!paused&&!document.hidden&&!reduced.matches){
 if(!blending&&v.readyState>=2&&next.readyState>=2&&v.duration-v.currentTime<=1.15){blending=true;blendElapsed=0;next.currentTime=0;next.style.opacity='0';next.style.zIndex='2';v.style.zIndex='1';play(next)}
 if(blending){blendElapsed+=dt;const p=Math.min(1,blendElapsed/1150);next.style.opacity=String(p);if(p===1){v.pause();v.style.opacity='0';v.style.zIndex='0';active=1-active;blending=false}}
 }requestAnimationFrame(loop)}
 videos[0].style.opacity='1';if(!deferred)reveal();requestAnimationFrame(loop);
})();
