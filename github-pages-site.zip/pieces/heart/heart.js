'use strict';
const NS='http://www.w3.org/2000/svg';
const phrases=[['I love you','en'],['Je t’aime','fr'],['Te amo','es'],['Ich liebe dich','de'],['Ti amo','it'],['Eu te amo','pt'],['Seni seviyorum','tr'],['Aku cinta kamu','id'],['Mahal kita','fil'],['Tôi yêu em','vi'],['愛してる','ja'],['사랑해','ko'],['我爱你','zh'],['ฉันรักคุณ','th'],['Я тебя люблю','ru'],['Я тебе кохаю','uk'],['Kocham cię','pl'],['Te iubesc','ro'],['Σ’ αγαπώ','el'],['אני אוהב אותך','he'],['أحبك','ar'],['मैं तुमसे प्यार करता हूँ','hi'],['আমি তোমাকে ভালোবাসি','bn'],['நான் உன்னை காதலிக்கிறேன்','ta'],['Ek is lief vir jou','af'],['Nakupenda','sw'],['Mi amas vin','eo'],['Szeretlek','hu'],['Volim te','hr'],['Miluji tě','cs'],['Ľúbim ťa','sk'],['Ljubim te','sl'],['Jeg elsker dig','da'],['Jag älskar dig','sv'],['Jeg elsker deg','no'],['Rakastan sinua','fi'],['Ég elska þig','is'],['Ik hou van jou','nl'],['Aš tave myliu','lt'],['Es tevi mīlu','lv'],['Ma armastan sind','et']];
const centerText='အရမ်းချစ်တယ် ကို့ကလေးလေး';
const holder=document.querySelector('#heart'),svg=document.createElementNS(NS,'svg');svg.setAttribute('viewBox','0 0 1000 900');svg.setAttribute('aria-hidden','true');holder.append(svg);
const measure=document.createElement('canvas').getContext('2d');
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
let labels=[],center,elapsed=0,last=0,paused=false,shown=0,ready=false;
let playbackAllowed=new URLSearchParams(location.search).get('prelude')!=='1';
document.body.classList.toggle('waiting',!playbackAllowed);
addEventListener('message',event=>{if(event.origin===location.origin&&event.source===parent&&event.data==='start-heart'){playbackAllowed=true;document.body.classList.remove('waiting');last=0}});
function point(t,scale){const x=24*scale*16*Math.sin(t)**3,y=-24*scale*(13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t));
 // Shared, gentle irregularities keep every shell part of the same hand-shaped heart.
 return{x:500+x*(1+.027*Math.sin(t*3+.5))+scale*5*Math.sin(t*7),y:390+y+scale*(12*Math.sin(t)+5*Math.sin(t*5+.8))};}
function overlaps(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y}
function textNode(text,x,y,size,lang){const node=document.createElementNS(NS,'text');node.textContent=text;node.setAttribute('x',x.toFixed(2));node.setAttribute('y',y.toFixed(2));node.setAttribute('font-size',size);node.setAttribute('text-anchor','middle');node.setAttribute('dominant-baseline','middle');node.setAttribute('lang',lang);svg.append(node);return node}
function build(){svg.replaceChildren();labels=[];const occupied=[{x:326,y:404,w:348,h:54}];let phraseIndex=0;
 for(let ring=0;ring<7;ring++){const scale=[1,.86,.72,.58,.44,.30,.16][ring],size=ring<2?12:11.5;let distance=100,prev=point(0,scale),nextGap=0;
 for(let i=0;i<2400;i++){const t=i/2400*Math.PI*2,p=point(t,scale);distance+=Math.hypot(p.x-prev.x,p.y-prev.y);prev=p;if(distance<nextGap)continue;
 measure.font=`600 ${size}px "Noto Sans", Arial`;let [phrase,lang]=phrases[phraseIndex%phrases.length];while(measure.measureText(phrase).width>100){phraseIndex++;[phrase,lang]=phrases[phraseIndex%phrases.length]}const w=measure.measureText(phrase).width+5;const box={x:p.x-w/2,y:p.y-8.5,w,h:17};
 if(occupied.some(b=>overlaps(box,b)))continue;
 const node=textNode(phrase,p.x,p.y,size,lang);node.style.fill=['#f0786d','#e96868','#ef8f70','#db697b','#f0a07e'][(phraseIndex+ring)%5];node.dataset.ring=ring;node.dataset.angle=t;labels.push({node,ring,t});occupied.push(box);phraseIndex++;distance=0;nextGap=Math.max(22,w*.48);
 }}
 // Fade duration shortens continuously through the clockwise reveal.
 for(let i=0;i<labels.length;i++){const progress=i/Math.max(1,labels.length-1);labels[i].node.style.transitionDuration=`${(2.6-2.15*progress).toFixed(3)}s`}
 center=textNode(centerText,500,433,24,'my');center.classList.add('center');elapsed=0;shown=0;ready=true;
 console.assert(labels.length>50&&labels.every((x,i)=>!i||x.ring>=labels[i-1].ring),'Heart shell order invalid');
}
function frame(now){if(!last)last=now;const dt=Math.min((now-last)/1000,.2);last=now;if(ready&&playbackAllowed&&!paused){elapsed+=dt;const count=reduce.matches?labels.length:Math.min(labels.length,Math.floor(Math.max(0,elapsed-.7)/.24));while(shown<count)labels[shown++].node.classList.add('revealed');if(reduce.matches||elapsed>labels.length*.24+3.0){center.classList.add('revealed');document.body.classList.add('center-finished');document.querySelector('#next-piece').hidden=false}}requestAnimationFrame(frame)}
document.querySelector('#pause').onclick=e=>{paused=!paused;dispatchEvent(new CustomEvent('heart-pause',{detail:paused}));e.target.textContent=paused?'Resume':'Pause';e.target.setAttribute('aria-label',paused?'Resume heart formation':'Pause heart formation')};
document.querySelector('#replay').onclick=()=>{elapsed=0;shown=0;paused=false;last=0;document.body.classList.remove('center-finished');dispatchEvent(new CustomEvent('heart-pause',{detail:false}));for(const {node} of labels)node.classList.remove('revealed');center.classList.remove('revealed');document.querySelector('#pause').textContent='Pause';document.querySelector('#pause').setAttribute('aria-label','Pause heart formation')};
// Wait for font shaping before placing phrases so the Burmese and other scripts stay intact.
Promise.race([Promise.all([document.fonts.load('600 12px "Noto Sans"'),document.fonts.load('500 24px "Noto Sans Myanmar"',centerText)]),new Promise(resolve=>setTimeout(resolve,3000))]).then(build);
requestAnimationFrame(frame);

document.querySelector('#next-piece').addEventListener('click',event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();const destination=new URL('../outro/',location.href).href;if(parent!==window&&parent.location.pathname.includes('/pieces/prelude/'))parent.location.href=destination;else location.href=destination});
